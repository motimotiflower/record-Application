package com.example.sample3;

//画面遷移のインポート
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.sample3.Todo.edit.activity.TodoEditActivity;
import com.example.sample3.Todo.home.activity.TodoHomeActivity;
import com.example.sample3.memo.edit.activity.Memo_editActivity1;
import com.example.sample3.memo.home.activity.MemoHomeActivity;
import com.example.sample3.db.DatabaseHelper;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper _helper = null; //Database

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //画面遷移
        //memo_home(メモ一覧画面)へ
        Button memolistButton = findViewById(R.id.memo_list);
        memolistButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MemoHomeActivity.class);
                startActivity(intent);
            }
        });

        //memo_edit(メモ編集画面)へ
        Button memoeditButton = findViewById(R.id.memo_make);
        memoeditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Memo_editActivity1.class);
                startActivity(intent);
            }
        });

        //todo_edit(タスク編集画面)へ
        Button todoeditButton = findViewById(R.id.todo_make);
        todoeditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TodoEditActivity.class);
                startActivity(intent);
            }
        });

        //todo_list(タスクホーム画面)へ
        Button todolistButton = findViewById(R.id.todo_list);
        todolistButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TodoHomeActivity.class);
                startActivity(intent);
            }
        });




        //DatabaseHelperオブジェクトの生成
        _helper = new DatabaseHelper(MainActivity.this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }




    @Override
    protected void onDestroy() {
        //DatabaseHelperオブジェクトの解散
        _helper.close();
        super.onDestroy();
    }


}