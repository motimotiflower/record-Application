package com.example.sample3.Todo.edit.activity;

import android.content.ContentValues;
import android.content.Intent;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sample3.db.DBContract;
import com.example.sample3.db.DatabaseHelper;
import com.example.sample3.Todo.edit.fragment.Fragment_Textview_Todo;
import com.example.sample3.R;
import com.example.sample3.Todo.home.activity.TodoHomeActivity;

public class TodoEditActivity extends AppCompatActivity {

    //*************** メンバ ***************
    private DatabaseHelper dbHelper;
    private long savedTodoId = -1; // 編集中のメモID（フィールド化）

    
    //****************************************** onCreate() ***********************************************
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_edit);

        //前画面から渡されたIntentのデータをここで受け取る
        Intent intent = getIntent();

        //FragmentAの表示
        if (savedInstanceState == null) {
            Fragment_Textview_Todo fragment = new Fragment_Textview_Todo();

            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .add(R.id.fragment_container_todo1,fragment)
                    .commit();
        }

        dbHelper = new DatabaseHelper(this);

        // 決定ボタンで Todo を保存（上書き or 新規）
        Button decideTodoButton = findViewById(R.id.button_todoedit_decide);
        decideTodoButton.setOnClickListener(v -> {

            // 連打防止
            decideTodoButton.setEnabled(false);
            decideTodoButton.postDelayed(() -> decideTodoButton.setEnabled(true), 800);

            Fragment_Textview_Todo fragment = (Fragment_Textview_Todo) getSupportFragmentManager()
                    .findFragmentById(R.id.fragment_container_todo1);

            if (fragment != null) {

                // Fragment からタイトルや完了フラグを取得
                String todoTitle = fragment.getInputTitle();
                boolean todoDone = fragment.isDone();

                // DBHelper を使用
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                ContentValues values = new ContentValues();
                values.put(DBContract.TodoEntry.COLUMN_NAME_TITLE, todoTitle);
                values.put(DBContract.TodoEntry.COLUMN_NAME_DONE, todoDone ? 1 : 0);

                String toastMessage;

                if (savedTodoId == -1) {
                    // 新規作成
                    Cursor cursor = db.rawQuery("SELECT MAX(" + DBContract.TodoEntry._ID + ") FROM " + DBContract.TodoEntry.TABLE_NAME, null);
                    long lastId = 0;
                    if (cursor.moveToFirst()) lastId = cursor.getLong(0);
                    cursor.close();
                    savedTodoId = lastId + 1;

                    long newRowId = db.insert(DBContract.TodoEntry.TABLE_NAME, null, values);
                    toastMessage = "新規作成しました (ID: " + newRowId + ")";

                } else {
                    // 更新
                    String selection = DBContract.TodoEntry._ID + " = ?";
                    String[] selectionArgs = { String.valueOf(savedTodoId) };

                    int count = db.update(DBContract.TodoEntry.TABLE_NAME, values, selection, selectionArgs);
                    toastMessage = (count > 0) ? "更新しました (ID: " + savedTodoId + ")" : "更新に失敗しました";
                }

                // SharedPreferences に保存
                SharedPreferences prefs = getSharedPreferences("TodoPrefs", MODE_PRIVATE);
                prefs.edit().putLong("saved_todo_id", savedTodoId).apply();

                db.close();

                // 前の Toast をキャンセルしてから表示
                if (currentToast != null) currentToast.cancel();
                currentToast = Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT);
                currentToast.show();
            }
        });

    }

    //*************************************** onCreate()おわり **********************************************

    //戻るボタンを押したらTodoHomeActivityへ遷移
    @Override
    public void onBackPressed() {
        // TodoHome に遷移するIntentを作成
        Intent intent = new Intent(this, TodoHomeActivity.class);

        // 必要なら前のアクティビティをすべてクリアして遷移する場合
        // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

        startActivity(intent);

        // このアクティビティを終了
        finish();
    }

}