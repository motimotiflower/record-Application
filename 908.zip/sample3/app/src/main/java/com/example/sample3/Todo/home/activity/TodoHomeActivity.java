package com.example.sample3.Todo.home.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sample3.memo.home.fragment.MemoHomeListFragment;
import com.example.sample3.R;
import com.example.sample3.Todo.edit.activity.TodoEditActivity;

public class TodoHomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_edit);

    }

}
