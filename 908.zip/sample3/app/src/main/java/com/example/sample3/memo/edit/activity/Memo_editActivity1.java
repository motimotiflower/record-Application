package com.example.sample3.memo.edit.activity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.sample3.db.DBContract;
import com.example.sample3.db.DatabaseHelper;
import com.example.sample3.memo.edit.fragment.FragmentB_memo;
import com.example.sample3.memo.edit.fragment.Fragmentmemo_menu;
import com.example.sample3.R;
import com.example.sample3.memo.home.activity.MemoHomeActivity;
import com.example.sample3.model.Memo;

public class Memo_editActivity1 extends AppCompatActivity {

    //*************** メンバ ***************

    private boolean isFragmentVisible = false; // 状態を管理する変数
    private Toast currentToast; //toastの連続表示からのエラーを防ぐための変数

    //DBに使用
    private static final String PREFS_NAME = "MemoPrefs";
    private static final String KEY_MEMO_ID = "saved_memo_id";


    private long savedMemoId = -1; // 編集中のメモID（フィールド化）

    private DatabaseHelper dbHelper;


    //****************************************** onCreate() ***********************************************
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memo_edit);

        dbHelper = new DatabaseHelper(this);

        //前画面から渡されたIntentのデータをここで受け取る
        Intent intent = getIntent();
        savedMemoId = intent.getLongExtra("memo_id", -1);
        String memoContent = intent.getStringExtra("memo_content");

        //この画面を開いたときメモのIDの確認
        Log.i("テスト","ID: " + savedMemoId );

        //FragmentBの表示
        if (savedInstanceState == null) {
            FragmentB_memo fragment = new FragmentB_memo();

            // Bundleでデータを渡す
            Bundle args = new Bundle();
            args.putString("memo_content", memoContent);
            fragment.setArguments(args);

            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .add(R.id.fragment_container_memo1, fragment)
                    .commit();
        }

        //********************************
        // 決定ボタンでメモを保存（上書き or 新規）
        Button decideButton = findViewById(R.id.button_memoedit_decide);
        decideButton.setOnClickListener(v -> {

            // 連打防止：一時的にボタンを無効化
            decideButton.setEnabled(false);
            decideButton.postDelayed(() -> decideButton.setEnabled(true), 800);

            FragmentB_memo fragment = (FragmentB_memo) getSupportFragmentManager().findFragmentById(R.id.fragment_container_memo1);

            if (fragment != null) {

                //fragmentから文字を取得
                String inputText = fragment.getInputText();

                //データベースを開く
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                ContentValues values = new ContentValues();
                values.put(DBContract.DBEntry.COLUMN_NAME_TITLE, "メモ");
                values.put(DBContract.DBEntry.COLUMN_NAME_CONTENTS, inputText);


                String toastMessage;

                if (savedMemoId == -1) {

                    // 新規作成
                    Cursor cursor = db.rawQuery("SELECT MAX(" + DBContract.DBEntry._ID + ") FROM " + DBContract.DBEntry.TABLE_NAME, null);
                    long lastId = 0;
                    if (cursor.moveToFirst()) lastId = cursor.getLong(0);
                    cursor.close();
                    savedMemoId = lastId + 1;
                    long newRowId = db.insert(DBContract.DBEntry.TABLE_NAME, null, values);
                    toastMessage = "新規作成しました (ID: " + newRowId + ")";

                } else {

                    // 編集
                    String selection = DBContract.DBEntry._ID + " = ?";
                    String[] selectionArgs = { String.valueOf(savedMemoId) };
                    int count = db.update(DBContract.DBEntry.TABLE_NAME, values, selection, selectionArgs);
                    toastMessage = (count > 0) ? "更新しました (ID: " + savedMemoId + ")" : "更新に失敗しました";
                }

                // 新規作成 or 編集後にIDをSharedPreferencesに保存
                SharedPreferences prefs = getSharedPreferences("MemoPrefs", MODE_PRIVATE);
                prefs.edit().putLong(KEY_MEMO_ID, savedMemoId).apply();

                db.close();

                // 前の Toast をキャンセルしてから新しく表示
                if (currentToast != null) currentToast.cancel();

                currentToast = Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT);
                currentToast.show();

            }

        });

        //********************************
        //imageButtonを押したとき、フラグメントを見て状況に応じて表示する
        ImageButton toggleFragmentButton = findViewById(R.id.imageButton_memoedit);
        toggleFragmentButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                Fragment currentFragment = fragmentManager.findFragmentById(R.id.fragment_container_memo2);

                if (currentFragment == null) {
                    // 表示：フラグメントを追加
                    fragmentManager.beginTransaction()
                            .setReorderingAllowed(true)
                            .replace(R.id.fragment_container_memo2, Fragmentmemo_menu.class, null)
                            .commit();
                    isFragmentVisible = true;
                } else {
                    // 非表示：フラグメントを削除
                    fragmentManager.beginTransaction()
                            .remove(currentFragment)
                            .commit();
                    isFragmentVisible = false;
                }
            }

        });

    }
    //*************************************** onCreate()おわり **********************************************

    //戻るボタンを押したらMemoHomeActivityへ遷移
    @Override
    public void onBackPressed() {
        // MemoHome に遷移するIntentを作成
        Intent intent = new Intent(this, MemoHomeActivity.class);

        // 必要なら前のアクティビティをすべてクリアして遷移する場合
        // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

        startActivity(intent);

        // このアクティビティを終了
        finish();
    }

}