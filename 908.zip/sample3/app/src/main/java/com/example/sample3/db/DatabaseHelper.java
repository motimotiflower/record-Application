package com.example.sample3.db;

import static com.example.sample3.db.DBContract.DBEntry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.sample3.model.Memo;
import com.example.sample3.model.Todo;

import java.util.ArrayList;
import java.util.List;

// データベースをアプリから使用するために、 SQLiteOpenHelperを継承する
// SQLiteOpenHelperは、データベースやテーブルが存在する場合はそれを開き、存在しない場合は作成してくれる
public class DatabaseHelper extends SQLiteOpenHelper {

    // データベースのバージョン
    // テーブルの内容などを変更したら、この数字を変更する
    static final private int VERSION = 1;

    // データベース名
    static final private String DBNAME = "app.db";

    // コンストラクタ
    public DatabaseHelper(Context context) {
        // 親クラスのコンストラクタを呼ぶ
        super(context, DBNAME, null, VERSION);
    }

    //SQL 定義
    @Override
    // データベース作成時にテーブルを作成
    public void onCreate(SQLiteDatabase db) {

        //**************** memo *************
        // テーブルを作成
        db.execSQL(
                "CREATE TABLE " + DBEntry.TABLE_NAME + " (" +
                        DBEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        DBEntry.COLUMN_NAME_TITLE + " TEXT default 'タイトル', " +
                        DBEntry.COLUMN_NAME_CONTENTS + " TEXT default '', " +
                        DBEntry.COLUMN_NAME_UPDATE + " INTEGER DEFAULT (datetime(CURRENT_TIMESTAMP,'localtime'))) ");

        // トリガーを作成
        db.execSQL(
                "CREATE TRIGGER trigger_samp_tbl_update AFTER UPDATE ON " + DBEntry.TABLE_NAME +
                        " BEGIN " +
                        " UPDATE " + DBEntry.TABLE_NAME + " SET up_date = DATETIME('now', 'localtime') WHERE rowid == NEW.rowid; " +
                        " END;");


        //************* タスク *****************
        //タスクテーブル作成
        db.execSQL(
                "CREATE TABLE " + DBContract.TodoEntry.TABLE_NAME + " (" +
                        DBContract.TodoEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        DBContract.TodoEntry.COLUMN_NAME_TITLE + " TEXT default '', " +
                        DBContract.TodoEntry.COLUMN_NAME_DONE + " INTEGER default 0, " +
                        DBContract.TodoEntry.COLUMN_NAME_UPDATE + " INTEGER DEFAULT (datetime(CURRENT_TIMESTAMP,'localtime'))) "
        );

        // トリガー作成（更新時に up_date を更新）
        db.execSQL(
                "CREATE TRIGGER trigger_todo_update AFTER UPDATE ON " + DBContract.TodoEntry.TABLE_NAME +
                        " BEGIN " +
                        " UPDATE " + DBContract.TodoEntry.TABLE_NAME + " SET up_date = DATETIME('now', 'localtime') WHERE rowid == NEW.rowid; " +
                        " END;"
        );
    }

    @Override
    // データベースをバージョンアップした時、テーブルを削除してから再作成
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //db.execSQL("DROP TABLE IF EXISTS " + DBEntry.TABLE_NAME);
        //onCreate(db);
    }

    //************************************* メモの処理 **********************************************
    //メモを保存する処理
    public long insertMemo(Memo memo) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DBEntry.COLUMN_NAME_TITLE, memo.getTitle());
        values.put(DBEntry.COLUMN_NAME_CONTENTS, memo.getContent());

        long newRowId = db.insert(DBEntry.TABLE_NAME, null, values);

        db.close();
        return newRowId;
    }

    // メモ更新
    public int updateMemo(Memo memo) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DBEntry.COLUMN_NAME_TITLE, memo.getTitle());
        values.put(DBEntry.COLUMN_NAME_CONTENTS, memo.getContent());

        String selection = DBEntry._ID + " = ?";
        String[] selectionArgs = { String.valueOf(memo.getId()) };

        int count = db.update(DBEntry.TABLE_NAME, values, selection, selectionArgs);
        db.close();
        return count;
    }

    // IDでメモ削除
    public int deleteMemoById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = DBEntry._ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        int deletedRows = db.delete(DBEntry.TABLE_NAME, selection, selectionArgs);
        db.close();
        return deletedRows;
    }

    //データベースから全てのメモを取得しMemo オブジェクトのリストとして返す
    public List<Memo> getAllMemos() {
        List<Memo> memoList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        //SQL文
        Cursor cursor = db.query(
                DBEntry.TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                DBEntry.COLUMN_NAME_UPDATE + " DESC"  // 新しい順に表示
        );

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(DBEntry._ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DBEntry.COLUMN_NAME_TITLE));
            String content = cursor.getString(cursor.getColumnIndexOrThrow(DBEntry.COLUMN_NAME_CONTENTS));
            memoList.add(new Memo(id, title, content));
        }

        cursor.close();
        db.close();
        return memoList;
    }

    //******************************************* タスクの処理 ********************************************

    public long insertTodo(Todo todo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBContract.TodoEntry.COLUMN_NAME_TITLE, todo.getTitle());
        values.put(DBContract.TodoEntry.COLUMN_NAME_DONE, todo.isDone() ? 1 : 0);

        long newRowId = db.insert(DBContract.TodoEntry.TABLE_NAME, null, values);
        db.close();
        return newRowId;
    }

    public int updateTodo(Todo todo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBContract.TodoEntry.COLUMN_NAME_TITLE, todo.getTitle());
        values.put(DBContract.TodoEntry.COLUMN_NAME_DONE, todo.isDone() ? 1 : 0);

        String selection = DBContract.TodoEntry._ID + " = ?";
        String[] selectionArgs = { String.valueOf(todo.getId()) };

        int count = db.update(DBContract.TodoEntry.TABLE_NAME, values, selection, selectionArgs);
        db.close();
        return count;
    }

    public int deleteTodoById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = DBContract.TodoEntry._ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        int deletedRows = db.delete(DBContract.TodoEntry.TABLE_NAME, selection, selectionArgs);
        db.close();
        return deletedRows;
    }

    public List<Todo> getAllTodos() {
        List<Todo> todoList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(DBContract.TodoEntry.TABLE_NAME, null, null, null, null, null,
                DBContract.TodoEntry.COLUMN_NAME_UPDATE + " DESC");

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(DBContract.TodoEntry._ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DBContract.TodoEntry.COLUMN_NAME_TITLE));
            boolean done = cursor.getInt(cursor.getColumnIndexOrThrow(DBContract.TodoEntry.COLUMN_NAME_DONE)) == 1;
            todoList.add(new Todo(id, title, done));
        }

        cursor.close();
        db.close();
        return todoList;
    }

}

